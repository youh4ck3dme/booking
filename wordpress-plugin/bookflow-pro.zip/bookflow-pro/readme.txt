=== BookFlow Pro ===
Contributors: bookflow
Tags: booking, appointment, calendar
Requires at least: 5.8
Tested up to: 6.4
Stable tag: 1.0.0
License: GPLv2 or later

Premium booking system integration for BookFlow Pro.

== Description ==
Embed BookFlow Pro booking widget to let visitors book appointments directly.

== Installation ==
1. Upload the plugin folder to `/wp-content/plugins/`
2. Activate in 'Plugins' menu
3. Configure in 'Settings > BookFlow Pro'

== Changelog ==
= 1.0.0 =
* Initial release
